import time 

class Cache:
    # timeout the time the cache will be valid in millis
    def __init__(self, timeout, callback) -> None:
        self.cb = callback
        self.value = callback()
        self.timeout = timeout
        self.timeout_cache = timeout + time.time() * 1000 
    def get_value():
        if time.time() * 1000 >= self.timeout_cache:
            # get a new value 
            self.timeout_cache = self.timeout + time.time() * 1000 
            self.value = callback 
        return self.value 
